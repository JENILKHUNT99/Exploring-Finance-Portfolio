# Exploring_Finance_Potfolio

use mongoDB

# install Some Python Packages

(1)matplotlib
-> pip3 install matplotlib

(2)pymongo
-> pip3 install pymongo

(3)numpy
-> pip3 install numpy
