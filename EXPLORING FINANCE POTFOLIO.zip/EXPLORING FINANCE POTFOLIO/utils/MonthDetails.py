class Month:

    def __init__(self,revenue,debt,haveEquity,EBITDA,assets,marketing,grossProfit,netProfit,totalSalaries,COGS,totalTaxes,other,sales,shareMarket):
        self.revenue=revenue
        self.debt=debt
        self.haveEquity=haveEquity
        self.EBITDA=EBITDA     
        self.assets=assets
        self.marketing=marketing
        self.grossProfit=grossProfit
        self.netProfit=netProfit
        self.totalSalaries=totalSalaries
        self.COGS=COGS    #cost of Goods Sold
        self.totalTaxes=totalTaxes
        self.other=other
        self.sales=sales
        self.shareMarket=shareMarket
